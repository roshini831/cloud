-- MySQL dump 10.17  Distrib 10.3.24-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: attendance
-- ------------------------------------------------------
-- Server version	10.3.24-MariaDB-2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` tinytext NOT NULL,
  `password` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'admin','admin'),(2,'admin2','admin2');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `markattendance`
--

DROP TABLE IF EXISTS `markattendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `markattendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(255) NOT NULL,
  `enrollment` varchar(11) NOT NULL,
  `markedBy` varchar(255) NOT NULL,
  `attendance` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=199 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `markattendance`
--

LOCK TABLES `markattendance` WRITE;
/*!40000 ALTER TABLE `markattendance` DISABLE KEYS */;
INSERT INTO `markattendance` VALUES (194,'16-11-2020','19001','Sumo','P'),(195,'16-11-2020','19003','Sumo','A'),(196,'16-11-2020','19004','Sumo','P'),(197,'16-11-2020','19005','Sumo','A'),(198,'16-11-2020','19006','Sumo','P');
/*!40000 ALTER TABLE `markattendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `course` varchar(11) NOT NULL,
  `semester` tinyint(4) NOT NULL,
  `email` tinytext NOT NULL,
  `enrollment` varchar(11) NOT NULL,
  `password` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'Yasasvi','Yenigalla','OS',2,'yasasvi@gmail.com','19001','student'),(2,'Manish','Guptha','DSA',3,'manish@gmail.com','18001','student'),(3,'Hitesh','Lade','DBMS',3,'hitesh@gmail.com','18002','student'),(4,'Sumanth','Dodda','C',2,'sumo@gmail.com','19002','student'),(5,'Tejaswini','Anuhya','DSA',3,'tejaswi@gmail.com','18003','student'),(6,'Sureka','Vendoti','DBMS',3,'sureka@gmail.com','18004','student'),(7,'Siddharth','Singh','EVS',1,'ssingh@gmail.com','20001','student'),(8,'Preeti','Gupta','DBMS',3,'pgupta@gmail.com','18005','student'),(9,'Aashish','Sundar','EEE',1,'aashish@gmail.com','20002','student'),(10,'Ashutosh','Yadav','DBMS',3,'ashyadav@gmail.com','18006','student'),(11,'Harshit','Kumar','DBMS',3,'kumarharshit@gmail.com','18007','student'),(12,'Meghana','Dodda','OS',2,'megha@gmail.com','19003','student'),(13,'Nitin','Kumar','DBMS',3,'kumarnitin@gmail.com','18008','student'),(14,'Likhitha','Dodda','DBMS',3,'ldodda@gmail.com','18009','student'),(15,'Simran','Reddy','DBMS',3,'schopra@gmail.com','18010','student'),(16,'Hemanth','Naidu','OS',2,'hnaidu@gmail.com','19004','student'),(17,'Karthik','Krishna','DBMS',3,'krishna@gmail.com','18011','student'),(18,'Mihir','Reddy','DSA',3,'mihir@gmail.com','18012','student'),(19,'Aakash','Yadav','EEE',1,'akky@gmail.com','20003','student'),(20,'Varshitha','Reddy','OS',2,'varsi@gmail.com','19005','student'),(21,'Deepika','Kuluru','DBMS',3,'deepika@gmail.com','18013','student'),(22,'Venkata','Lakshmi','EEE',1,'venkata@gmail.com','20004','student'),(23,'Teja','Kotisetty','OS',2,'teja@gmail.com','19006','student'),(24,'Mayank','Chowdary','DBMS',3,'mayank@gmail.com','18014','student'),(25,'Padikkal','Devadutt','EVS',1,'padikkal@bcci.com','20005','student'),(26,'bhuvan','bam','EEE',1,'bhuvan@gmail.com','20006','student');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `semester` tinyint(4) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (6,'Vamsi','F','EEE',1,'vamsi@hel.com','vamsi','vamsi'),(5,'Bheema raju','A','EVS',1,'bheem@hello.com','bheem','bheem'),(4,'Aneesha','G','DSA',3,'ani@yahoo.com','anish','anish'),(3,'Sumo','D','OS',2,'sumo@gmail.com','sumo','Sumo'),(2,'Manish','C','C',2,'man@bho.com','mani','mani'),(1,'Gayatri','G','DBMS',3,'gg@gmail.com','gayatri','gayatri');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-16 21:04:31
