<?php phpinfo();

?>
