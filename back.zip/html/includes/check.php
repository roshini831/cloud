<?php
$mysqli = new mysqli("database-1.cggpqx4z4bll.us-east-1.rds.amazonaws.com","admin","adminhere","attendance");

// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}
?>
