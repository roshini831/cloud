<?php
	$con=new mysqli('database-1.cggpqx4z4bll.us-east-1.rds.amazonaws.com','admin','adminhere','attendance'); 
?>
